#include<iostream>//append clear find erase length/size substr stoi
#include<string>
#include<algorithm>
using namespace std;
int main()
{
    string n="56498762357";

    sort(n.begin(),n.end(),greater<int>());

    
cout<<n;
    

    
    
    return 0;
}