#include<iostream>// 3 4 5 6 7 8 4
using namespace std;

int main()
{ 
    int n,m;
    cin>>n>>m;
    if(n>m)
    {
        cout<<n<<"is maximum";
        cout<<m<<"is minimum";
    }
    else{
        cout<<m<<"is maximum";
        cout<<n<<"is minimum";
    }
   return 0;
}
