#include<iostream>// 3 4 5 6 7 8 4
using namespace std;

int main()
{ 
    int n;
    cin>>n;
    int sum=0;
    for(int i=1;i<=n;i++)
    {
        sum=sum+i;
    }
    cout<<sum;
   return 0;
}
