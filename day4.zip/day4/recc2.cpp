//program to replace pi with 3.14 using recursion
#include<iostream>
#include<string>
using namespace std;

void replace(string s)
{
    if(s.length()==0) //base cond
    {
        return;
    }

   if(s[0]=='p' && s[1]=='i')
   {
       cout<<"3.14";
       replace(s.substr(2));
   }
   else
   {
       cout<<s[0];
       replace(s.substr(1));
   }

}

int main()
{
    string s;
    cout<<"enter string to be replaced";
    cin>>s;
    replace(s);
}