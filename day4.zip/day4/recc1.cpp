//program to reverse a string usind recursion
#include<iostream>
#include<string>
using namespace std;

void reverse(string s)
{
    if(s.length()==0)//base cond
    {
        return;
    }

    string rest=s.substr(1);
    reverse(rest);
    cout<<s[0]<<"\t";

}

int main()
{
    string s;
    cout<<"enter string to be reversed";
    cin>>s;
    reverse(s);
}