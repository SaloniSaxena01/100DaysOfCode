//Program to print all the substrings of a given string using recursion
#include<iostream>
#include<string>
using namespace std;

void substring(string s, string ans)
{
    if(s.size()==0)
    {
        cout<<ans<<endl;
        return;
    }
    string rest=s.substr(1);

    char ch=s[0];
    substring(rest,ans);
    substring(rest,ans+ch);

}

int main()
{
    substring("ABC", "");
}