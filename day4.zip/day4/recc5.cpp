//program to move all x at the end of the string using recursion
#include<iostream>
#include<string>
using namespace std;

string move(string s)
{
    if(s.size()==0) //base cond
    {
        return "";
    }
    char ch=s[0];
    string ans=move(s.substr(1));

    if(ch=='x')
    {
        return ans+ch;
    }
    return ch+ans;
    }

   


int main()
{
    
    cout<<move("axsdxxerfxxedxdd");
}