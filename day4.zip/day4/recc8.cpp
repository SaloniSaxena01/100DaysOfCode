//Program to print all possible words using keypad number using recursion
#include<iostream>
#include<string>
using namespace std;

string keypadarr[]={"","/","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};

void keypad(string s, string ans)
{
    if(s.size()==0)
    {
        cout<<ans<<endl;
        return;
    }
    string rest=s.substr(1);

    char ch=s[0];
    string code= keypadarr[ch-'0'];

    for(int i=0;i<code.size();i++)
    {
        keypad(rest, ans+code[i]);
    }
 

}

int main()
{
    keypad("23", "");
}