//program to remove duplicate in a string using recursion
#include<iostream>
#include<string>
using namespace std;

string duplicate(string s)
{
    if(s.size()==0) //base cond
    {
        return "";
    }
    char ch=s[0];
    string ans=duplicate(s.substr(1));

    if(ch==ans[0])
    {
        return ans;
    }
    else{
        return ch+ans;
    }

   
}

int main()
{
    
    cout<<duplicate("aaaabbbbccccddddeeee");
}