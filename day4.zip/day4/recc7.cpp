//Program to print all the substrings of a given string along with their ASCII values using recursion
#include<iostream>
#include<string>
using namespace std;

void substring(string s, string ans)
{
    if(s.size()==0)
    {
        cout<<ans<<endl;
        return;
    }
    string rest=s.substr(1);

    char ch=s[0];
    int code=ch;
    substring(rest,ans);
    substring(rest,ans+ch);
    substring(rest,ans+ to_string(code));

}

int main()
{
    substring("AB", "");
}